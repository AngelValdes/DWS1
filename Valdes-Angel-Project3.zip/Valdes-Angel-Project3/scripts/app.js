﻿(function() {
    "use strict";

})();